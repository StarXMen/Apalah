echo Press 'Y' for all of them.
yum install epel-release
yum update -y
yum install python
python letsBuild.py centos