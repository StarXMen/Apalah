echo Press 'Y' for all of them.
apt update -y
apt install python
python letsBuild.py ubuntu