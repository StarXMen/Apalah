import os,sys,time,requests,math,io,string,json,discord
from datetime import datetime
from discord import file
from discord.ext import commands

now = datetime.now()
client = commands.Bot(command_prefix='$',case_insensitive=True)
token = ('OTE4NjEwODU5OTQzNjU3NTUy.YbJxBw.FlyDOoMCGWPa1x0-820srE4NMbQ')
client.remove_command('help')

############ THIS BOT IS VERY VULNERABLE BUT ONLY OWNERS CAN USE THIS COMMAND NOT USERS.
@client.command(name='ban')
@commands.has_any_role('Owner')
async def help(ctx, ip):
    os.system(f"iptables -A INPUT -s {ip} -j DROP")
    print (f" [X] Banned {ip} ")
    embed1 = discord.Embed(title='IP Ban',color = discord.Color.from_rgb(255,0,0))
    embed1.add_field(name="Content", value=(
                     f"\n\nIP : ```{ip}``` was banned.\n\n"))
    embed1.set_image(url="https://cdn.discordapp.com/attachments/793626114434007090/793636545382711316/7F203D44-D00E-4735-87F7-CD774A6C3F9A.gif")
    await ctx.send(embed=embed1)

client.run(token)