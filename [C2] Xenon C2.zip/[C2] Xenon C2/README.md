# Xenon-C2 - Botnet build.
An open-source python C2 build, everything included.

# Discontinued
Xenon-C2 is discontinued, it was for fun.

# Reminder
The source is very vulnerable, it was made when i had basic python knowledge.

- I am not responsible for any type of harm against anyone for this source.


THIS SOURCE HAS ONLY BEEN TESTED ON AN WINDOWS DEVICE.
