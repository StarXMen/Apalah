"""
This python script was made by a skid and is being upgraded ocp!
"""
import argparse
from sys import exit
from os import path


class GradientFunc:

    clear="\033[0;00m"
    
    colors = {
        'pink':(222,31,171),
        'purple':(81,15,138),
        'blue':(12,25,222),
        'cyan':(5,189,245),
        'turquoise':(14,161,129),
        'lime':(5,225,9),
        'green':(4,85,6),
        'white':(255,255,255),
        'grey':(50,50,50),
        'red':(252,8,8),
        'yellow':(255,442,0)
    }

    ## This function only accepts arrays for startrgb and endrgb
    def gradiant(startrgb, endrgb, text: str):
        lenoft = len(text)
        changer = int((int(endrgb[0]) - int(startrgb[0]))/lenoft)
        changeg = int((int(endrgb[1]) - int(startrgb[1]))/lenoft)
        changeb = int((int(endrgb[2]) - int(startrgb[2]))/lenoft)

        r = int(startrgb[0])
        g = int(startrgb[1])
        b = int(startrgb[2])
        ourshit = ""
        for letter in text:
            ourshit += (f"\x1b[38;2;{r};{g};{b}m{letter}")
            r+=changer
            g+=changeg
            b+=changeb
        
        return ourshit

    def validatergb(rgb):
        if not len(rgb) == 3:
            return False

        try:
            if 0 <= int(rgb[0]) <= 255 and 0 <= int(rgb[1]) <= 255 and 0 <= int(rgb[2]) <= 255:
                return True
            else:
                return False
        except ValueError:
            return False
